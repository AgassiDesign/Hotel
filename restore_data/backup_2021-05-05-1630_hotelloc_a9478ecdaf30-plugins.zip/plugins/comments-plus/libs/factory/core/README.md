# Core Factory Framework

It performs the connection of system modules of the framework, is responsible for migrations, plugin updates, admin notifications, initialization of the plugin.
